'use strict';

module.exports = function(app) {
	// Routing logic   
	// ...
};