'use strict';

// Configuring the Articles module
angular.module('pergunta-resolvidas').run(['Menus',
	function(Menus) {
		// Set top bar menu items
		Menus.addMenuItem('topbar', 'Pergunta resolvidas', 'pergunta-resolvidas', 'dropdown', '/pergunta-resolvidas(/create)?');
		Menus.addSubMenuItem('topbar', 'pergunta-resolvidas', 'List Pergunta resolvidas', 'pergunta-resolvidas');
		Menus.addSubMenuItem('topbar', 'pergunta-resolvidas', 'New Pergunta resolvida', 'pergunta-resolvidas/create');
	}
]);