'use strict';

angular.module('membros').controller('CreateMembrosController', ['$scope',
	function($scope) {
		// Controller Logic
		// ...
	}
]);